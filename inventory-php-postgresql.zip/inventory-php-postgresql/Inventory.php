<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inventory System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		

		
	</div>



	<form class="form-style-1" method="post" action="Inventory.php">
		<?php include('error.php'); ?>
		<?php include('Success.php'); ?>

		<ul>
			<li>
				
			<input type="property_number" name="property_number" placeholder="Property Number">
			<span></span><input type="processor_model" name="processor_model" value="<?php echo $processor_model; ?>" placeholder="Property Model">
  		</li>
  		<li>
			<input type="speed" name="speed" value="<?php echo $speed; ?>" placeholder="Speed">
			<span></span>
			<input type="memory" name="memory" value="<?php echo $memory; ?>" placeholder="Memory">
		</li>
  		<li>
			<input type="brand" name="brand" value="<?php echo $brand; ?>" placeholder="Brand Name">
			<span></span>
			<input type="ipadd" name="ipadd" value="<?php echo $ipadd; ?>" placeholder="IP Address">
		</li>
  		<li>
			<input type="computer_name" name="computer_name" value="<?php echo $computer_name; ?>" placeholder="Computer Name"><span></span>
			<input type="os" name="os" value="<?php echo $os; ?>" placeholder="Operating System">
		</li>
  		<li>
			<input type="end_user" name="end_user" value="<?php echo $end_user; ?>" placeholder="End-user">
			<span></span>
			<input type="type" name="type" value="<?php echo $type; ?>" placeholder="Type">
		</li>
  		<li>
			<input type="antivirus" name="antivirus" value="<?php echo $antivirus; ?>" placeholder="Antivirus">
			<span></span>
			<input type="status" name="status" value="<?php echo $status; ?>" placeholder="Status">
		</li>
  		<li>
			<input type="location" name="location" value="<?php echo $location; ?>" placeholder="Location">
		</li>
		</ul>
		
		<button type="add" class="btn" name="add">SAVE</button>
		<button type="update" class="btn" onclick="return confirm('Are you sure you want to update this record?')" name="update">UPDATE</button>
		<button type="delete" class="btn" onclick="return confirm('Are you sure you want to delete this record?')" name="delete">DELETE</button>
		<button type="clear" class="btn" name="clear">CLEAR</button>
		<button type="search" class="btn" name="search">SEARCH</button>
		
		
		
	</form>

</body>
</html>

