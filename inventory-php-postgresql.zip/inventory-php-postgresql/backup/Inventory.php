<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inventory System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header">
		<h2>Inventory</h2>

		
	</div>



	<form method="post" action="Inventory.php">
		<?php include('errors.php'); ?>
		
		<div class="input-group">
			<label>Property Number *</label>
		<input type="property_number" name="property_number">
		</div>
		<div class="input-group">
			<label>Processor Model</label>
			<input type="processor_model" name="processor_model" value="<?php echo $processor_model; ?>"> 
  		</div>
		<div class="input-group">
			<label>Speed</label>
			<input type="speed" name="speed" value="<?php echo $speed; ?>">
		</div>
		<div class="input-group">
			<label>Memory(RAM)</label>
			<input type="memory" name="memory" value="<?php echo $memory; ?>">
		</div>
		<div class="input-group">
			<label>Brand</label>
			<input type="brand" name="brand" value="<?php echo $brand; ?>">
		</div>
		<div class="input-group">
			<label>IP Address</label>
			<input type="ipadd" name="ipadd" value="<?php echo $ipadd; ?>">
		<div>
		<div class="input-group">
			<label>Computer Name</label>
			<input type="computer_name" name="computer_name" value="<?php echo $computer_name; ?>">
		</div>
		<div class="input-group">
			<label>Operating System</label>
			<input type="os" name="os" value="<?php echo $os; ?>">
		</div>
		<div class="input-group">
			<label>End-User</label>
			<input type="end_user" name="end_user" value="<?php echo $end_user; ?>">
		</div>
		<div class="input-group">
			<label>Type</label>
			<input type="type" name="type" value="<?php echo $type; ?>">
		</div>
		<div class="input-group">
			<label>Antivirus</label>
			<input type="antivirus" name="antivirus" value="<?php echo $antivirus; ?>">
		</div>
		<div class="input-group">
			<label>Status</label>
			<input type="status" name="status" value="<?php echo $status; ?>">
		</div>
		<div class="input-group">
			<label>Location</label>
			<input type="location" name="location" value="<?php echo $location; ?>">
		</div>
		<div class="input-group">
		<button type="add" class="btn" name="add">ADD</button>
		<button type="update" class="btn" name="update">UPDATE</button>
		<button type="delete" class="btn" name="delete">DELETE</button>
		<button type="clear" class="btn" name="clear">CLEAR</button>
		<button type="search" class="btn" name="search">SEARCH</button>
		</div>
	</form>

</body>
</html>

