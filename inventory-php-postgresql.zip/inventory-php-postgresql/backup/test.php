
// Device Input
if (isset($_POST['save'])) {
  // receive all input values from the form
  $property_number = pg_escape_string($_POST['property_number']); 
  $processor_model = pg_escape_string($_POST['processor_model']);
  $speed = pg_escape_string($_POST['speed']);
  $memory = pg_escape_string($_POST['memory']);
  $brand = pg_escape_string($_POST['brand']);
  $ipadd = pg_escape_string($_POST['ip.add']);
  $computer_name = pg_escape_string($_POST['computer_name']);
  $os = pg_escape_string($_POST['os']);
  $end_user = pg_escape_string($_POST['end_user']);
  $type = pg_escape_string($_POST['type']);
  $antivirus = pg_escape_string($_POST['antivirus']);
  $status = pg_escape_string($_POST['status']);
  $location = pg_escape_string($_POST['location']);

  // form validation: ensure that the form is correctly filled ...
  if (empty($property_number)) { array_push($errors, "Property Number is required");
   }
  
  }

  
  // user check for property number
  $user_check = "SELECT * FROM Inventory WHERE property_number='$PROPERTY_NUMBER' LIMIT 1";
  $result = pg_query($db, $user_check);
  $invent = pg_fetch_assoc($result);
  
  if ($invent) { // if user exists
    if ($invent['property_number'] === $PROPERTY_NUMBER) {
      array_push($errors, "Property Number already exists");
    
  }
}
  // If no errors found, information will be saved to Inventory Table
  
    $con = "INSERT INTO Inventory (property_number, processor_model, speed, memory, brand, ipadd, computer_name, os, end_user, type, antivirus, status, location) VALUES ('$property_number','$processor_model','$speed','$memory','$brand','$ipadd','$computer_name','$os','$end_user','$type','$antivirus','$status','$location)";
    
    $result = pg_query($db, $con);

if (!$result) {
         die("Error in SQL query: " . pg_last_error());
     }

     echo "Data successfully inserted!";
