<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inventory System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="header"></div>



	<form class="form-style-1" method="post" action="Inventory.php">
		<?php include('error.php'); ?>
		<?php include('Success.php'); ?>

	<div class="page-bg">
	</div>

		<ul>
			<li>
				
			<input type="property_number" name="property_number" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $property_number; ?>" placeholder="Property Number* " >
			<span></span><input type="processor_model" name="processor_model" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $processor_model; ?>" placeholder="Property Model">
  		</li>
  		<li>
			<input type="speed" name="speed" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $speed; ?>" placeholder="Speed">
			<span></span>
			<input type="memory" name="memory" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $memory; ?>" placeholder="Memory">
		</li>
  		<li>
			<input type="brand" name="brand" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $brand; ?>" placeholder="Brand Name" >
			<span></span>
			<input type="ipadd" name="ipadd" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $ipadd; ?>" placeholder="IP Address">
		</li>
  		<li>
			<input type="computer_name" name="computer_name" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $computer_name; ?>" placeholder="Computer Name"><span></span>
			<input type="os" name="os" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $os; ?>" placeholder="Operating System">
		</li>
  		<li>
			<input type="end_user" name="end_user" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $end_user; ?>" placeholder="End-user">
			<span></span>
			  <strong>Type:</strong>
			  <select value="type" name="type" type="type">
					  <option selected="COMPUTER" value="COMPUTER">COMPUTER</option>
					  <option selected="PRINTER" value="PRINTER">PRINTER</option>
					  <option selected="selected" value="MOBILE">MOBILE</option>
					  <option selected="selected" value="SCANNER">SCANNER</option>
					  <option selected="selected" value="MONITOR">MONITOR</option>
					  <option selected="selected" value="MOUSE">MOUSE</option>
					  <option selected="selected" value="KEYBOARD">KEYBOARD</option>
					  <option selected="selected" value="UPS">AVR/UPS</option>


			  </select> 
		</li>
  		<li>
			<input type="antivirus" name="antivirus" value="<?php echo $antivirus; ?>" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $antivirus; ?>" placeholder="Antivirus">
			<span></span>
			<input type="status" name="status" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $status; ?>" placeholder="Status">
		</li>
  		<li>
			<input type="location" name="location" onkeyup="this.value=this.value.toUpperCase()" value="<?php echo $location; ?>" placeholder="Location">
		</li>
		</ul>
		
		<button type="add" class="btn" name="add">SAVE</button>
		<button type="update" class="btn" onclick="return confirm('Are you sure you want to update this record?')" name="update">UPDATE</button>
		<button type="delete" class="btn" onclick="return confirm('Are you sure you want to delete this record?')" name="delete">DELETE</button>
		<button type="clear" class="btn" name="clear">CLEAR</button>
		<button type="search" class="btn" name="search">SEARCH</button>

		<br></br>
      <a href="index.php">Main Menu </a>
       <a href="index.php?logout='1'" style="color: red; margin-left: 90%;">Logout</a> 

		
		
	</form>
</body>
</html>

