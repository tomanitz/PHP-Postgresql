<?php
  include ('server.php');
  $frequencies = array ();
  $query4 = pg_query($db, "SELECT antivirus, COUNT(*) FROM inventory GROUP BY antivirus");
  
 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Summary</title>

</head>
<body>
	<table align="center" border="1px" style="width: 300px; line-height: 30px">
		<tr>
			<th colspan="3"><h2>Anti-Virus Summary</h2></th>
		</tr>
			<t>
				<th >Anti-Virus</th>
				<th>Frequency</th>
			</t>
				<?php 
					
						while($row = pg_fetch_row($query4)) {
							
            		
				?>

			 <tr>
			 	<td align="center"><?php echo "{$row[0]}"; ?></td>
			 	<td align="center"><?php echo $frequencies[$row[0]] = $row[1]; ?></td>
			 	<td><?php echo $row['COUNT(*)']  = $row[1]; ?></td>
			 </tr>
	 	
	 	<?php 
	 		}
	 	 ?>

	 
	</table>

</body>
</html>