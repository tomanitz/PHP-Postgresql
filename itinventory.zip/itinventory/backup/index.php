<?php 

  include ('script.php');
  session_start(); 

  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


  <div class="page-bg">
  </div>

<div class="header">
  
</div>
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>


    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
      <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
      <p> 
        <br></br>

        <a href="Inventory.php?Inventoy='2'" style="color: blue;">Inventory</a> </p>
        

<!-- TreeView Menu -->
         <ul id="inquiry">
  <li><span class="caret">Inquiry</span>
    <ul class="nested">
      <li><span class="caret">List</span>
        <ul class="nested">
          <li><span class="caret">Summary</span>
            <ul class="nested">
              <li><a href="" target="popup" onclick="window.open('os-summary.php','popup','width=600,height=500'); return false;">• Operating System</a>
              <li><a href="" target="popup" onclick="window.open('av-summary.php','popup','width=600,height=500'); return false;">• Anti-Virus</a></li>

              <?php include ('script.php'); ?>
              
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
</ul> 


        <a href="index.php?logout='1'" style="color: red; margin-left: 90%">Logout</a> </p>
    <?php endif ?>
</div>
    
</body>
</html>