<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	
  </div>
	
  <form class="form-style-1" method="post" action="register.php">
  	<?php include('error.php'); ?>

    <div class="page-bg">
  </div>
  
    <ul>
  	<li>
  	   <input type="username" name="username" value="<?php echo $username; ?>" placeholder="username">
  	   <input type="email" name="email" value="<?php echo $email; ?>" placeholder="email">
    </li>
    <li>
  	   <input type="password" name="password_1" placeholder="password">
  	   <input type="password" name="password_2" placeholder="confirm password">
  	</li>
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	
  	<br></br>
    <p>Already a member? <a href="login.php">Sign in</a></p>
  </form>
</body>
</html>