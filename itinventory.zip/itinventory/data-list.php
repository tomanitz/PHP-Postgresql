<?php
 
    if(isset($_POST['filter']))
{


    $valueToSearch = $_POST['value'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM inventory WHERE CONCAT('property_number', processor_model, speed, memory, brand, ip_add, computer_name, os, end_user, type, antivirus, status, location, createdate) LIKE '%"+$valueToSearch+"%'";
    $search_result = filterTable($query);
    
} else {
    $query = "SELECT * FROM inventory";
    $search_result = filterTable($query);
}
// function to connect and execute the query
function filterTable($query)
{
    $connect = pg_connect("host=10.225.226.226 port=5433 dbname=itinventory user=inventory password=admin");
    $filter_Result = pg_query($connect, $query);
    return $filter_Result;
}

?>




<!DOCTYPE html>
<html>
<head>
	<title>Inventory</title>
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
	<form method="post" action="data-list.php">
	<table align="center" border="1px" >
		<tr>
			<th colspan="15"><h2 class="th">Inventory List</h2>
			
			</th>
		</tr>
			<t>
				<th>Property Number</th>
				<th>Processor Model</th>
				<th>Speed</th>
				<th>Memory</th>
				<th>Brand</th>
				<th>I.P Address</th>
				<th>Computer Name</th>
				<th>OS</th>
				<th>End-user</th>
				<th>Type</th>
				<th>Antivirus</th>
				<th>Status</th>
				<th>Location</th>
				<th>Date</th>
			</t>
				<?php 
					
					while ($row = pg_fetch_array($search_result)) {
							            		
				?>

			 <tr>

			 	<td align="center"><?php echo $row['property_number']; ?></td>
			 	<td align="center"><?php echo $row['processor_model']; ?></td>
			 	<td align="center"><?php echo $row['speed']; ?></td>
			 	<td align="center"><?php echo $row['memory']; ?></td>
			 	<td align="center"><?php echo $row['brand']; ?></td>
			 	<td align="center"><?php echo $row['ip_add']; ?></td>
			 	<td align="center"><?php echo $row['computer_name']; ?></td>
			 	<td align="center"><?php echo $row['os']; ?></td>
			 	<td align="center"><?php echo $row['end_user']; ?></td>
			 	<td align="center"><?php echo $row['type']; ?></td>
			 	<td align="center"><?php echo $row['antivirus']; ?></td>
			 	<td align="center"><?php echo $row['status']; ?></td>
			 	<td align="center"><?php echo $row['location']; ?></td>
			 	<td align="center"><?php echo $row['createdate']; ?></td>
			 </tr>
	 	
	 	<?php 
	 		}
	 		//<button  type="filter" class="btn" value="filter" name="filter">Filter</button>
			//<input class="value" type="text" name="value" onkeyup="this.value=this.value.toUpperCase()"  placeholder="Looking for..?">
	 	 ?>

	 	

		</table>
	</form>
</body>
</html>