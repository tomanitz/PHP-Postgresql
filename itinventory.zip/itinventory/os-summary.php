<?php
  include ('server.php');
  $frequencies = array ();
  $query4 = pg_query($db, "SELECT os, COUNT(*) FROM inventory GROUP BY  os ORDER BY os ASC ");
  
 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Summary</title>

</head>
<body>
	<table align="center" border="1px" style="width: 300px; line-height: 25px;">
		<tr>
			<th colspan="3"><h2>Operating System Summary</h2></th>
		</tr>
			<t>
				<th >OS</th>
				<th>Quantity</th>
			</t>
				<?php 
					
						while($row = pg_fetch_row($query4)) {
							
            	?>

			 <tr>
			 	<td align="center"><?php echo $row[0]; ?></td>
			 	<td align="center"><?php echo $row[1]; ?></td>
			 	
			 </tr>

			 

	 	
	 	<?php 
	 		}
	 	 ?>
	 	 	<tr>
		 	 	<?php
		 	 		$query5 = pg_query($db, "SELECT os FROM inventory");
		 	 			$rowcount=pg_num_rows($query5);
			 	?>
			 	 		 
			 	 	 <th align="center"><?php echo "TOTAL"; ?></th>
			 	 	 <td align="center"><?php echo $rowcount;  ?></td>
		 	 		
	 	 	</tr>

	 	 <?php pg_close($db); ?> 
	
	</table>

</body>
</html>