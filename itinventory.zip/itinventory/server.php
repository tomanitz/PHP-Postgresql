<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$error = array(); 
$Success = array();

// connect to the database
$db = pg_connect("host=10.225.226.226 port=5433 dbname=itinventory user=inventory password=admin");


// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from form
    $username = pg_escape_string($_POST['username']);
    $email = pg_escape_string($_POST['email']);
    $password_1 = pg_escape_string($_POST['password_1']);
    $password_2 = pg_escape_string($_POST['password_2']);

  // form validation: ensure that the form is correctly filled ...
  if (empty($username)) { array_push($error, "Username is required"); }
  if (empty($email)) { array_push($error, "Email is required"); }
  if (empty($password_1)) { array_push($error, "Password is required"); }
  if ($password_1 != $password_2) {array_push($error, "Password do not match"); }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = pg_query($db, $user_check_query);
  $user = pg_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($error, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($error, "email already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($error) == 0) {
  	$password = md5($password_1);//encrypt the password before saving in the database

  	$sql = "INSERT INTO users (username, email, password) 
  			  VALUES('$username', '$email', '$password')";
  	$result = pg_query($db, $sql);

 
  	$_SESSION['username'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');

      }
}

// ... 

// LOGIN USER
if (isset($_POST['login_user'])) {
  $username = pg_escape_string($_POST['username']);
  $password = pg_escape_string($_POST['password']);

  if (empty($username)) {
    array_push($error, "Username is required");
  }
  if (empty($password)) {
    array_push($error, "Password is required");
  }

  if (count($error) == 0) {
    $password = md5($password);
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $results = pg_query($db, $query);
    if (pg_num_rows($results) == 1) {
      $_SESSION['username'] = $username;
      $_SESSION['success'] = "You are now logged in";
      header('location: index.php');
    }else {
      array_push($error, "Wrong username/password combination");
    }
  }
}



// ... 

// ADD RECORD
if (isset($_POST['add'])) {
  // receive all input values from the form
    $property_number = pg_escape_string($_POST['property_number']); 
    $processor_model = pg_escape_string($_POST['processor_model']);
    $speed = pg_escape_string($_POST['speed']);
    $memory = pg_escape_string($_POST['memory']);
    $brand = pg_escape_string($_POST['brand']);
    $ipadd = pg_escape_string($_POST['ipadd']);
    $computer_name = pg_escape_string($_POST['computer_name']);
    $os = pg_escape_string($_POST['os']);
    $end_user = pg_escape_string($_POST['end_user']);
    $type = pg_escape_string($_POST['type']);
    $antivirus = pg_escape_string($_POST['antivirus']);
    $status = pg_escape_string($_POST['status']);
    $location = pg_escape_string($_POST['location']);

  // form validation: ensure that the form is correctly filled ...
  if (empty($property_number)) { array_push ($error, "Property Number is required"); 
    } else {
        if (empty($antivirus)) { $antivirus = "NONE";
     }
       if (empty($os)) { $os = "NONE";
    }
  


// first check the database to make sure property number does not exist.

$invent_check_query = "SELECT * FROM inventory WHERE property_number='$property_number' LIMIT 1";
  $Result = pg_query($db, $invent_check_query);
    $invent = pg_fetch_assoc($Result);
  
  if ($invent) { // if property number exists
    if ($invent['property_number'] === $property_number) {
      array_push($error, "Property number already exists");
    }

     }

  // Finally, register the item if there are no errors found
  if (count($error) == 0) {
    
    //Performing SQL Query
    $sql = "INSERT INTO inventory (property_number, processor_model, speed, memory, brand, ip_add, computer_name, os, end_user, type, antivirus, status, location, createdate) VALUES ('$property_number', '$processor_model', '$speed', '$memory', '$brand', '$ipadd', '$computer_name', '$os', '$end_user', '$type', '$antivirus' , '$status' , '$location' , current_timestamp)";
        


    $Result = pg_query($db, $sql);


    $_SESSION['success'] = "Record Successfuly Added";
    header('location: index.php'); 
     
  }


}

// ... 

// UPDATE RECORD
if (isset($_POST['update'])) {
  // receive all input values from the form
    $property_number = pg_escape_string($_POST['property_number']); 
    $processor_model = pg_escape_string($_POST['processor_model']);
    $speed = pg_escape_string($_POST['speed']);
    $memory = pg_escape_string($_POST['memory']);
    $brand = pg_escape_string($_POST['brand']);
    $ipadd = pg_escape_string($_POST['ipadd']);
    $computer_name = pg_escape_string($_POST['computer_name']);
    $os = pg_escape_string($_POST['os']);
    $end_user = pg_escape_string($_POST['end_user']);
    $type = pg_escape_string($_POST['type']);
    $antivirus = pg_escape_string($_POST['antivirus']);
    $status = pg_escape_string($_POST['status']);
    $location = pg_escape_string($_POST['location']);

  // form validation: ensure that the form is correctly filled ...
  if (empty($property_number)) { array_push($error, "Property Number is required");

  }
  
  
//  first check the database to make sure property number does exist.

$query2 = "SELECT * FROM inventory WHERE property_number='$property_number'";
    $results2 = pg_query($db, $query2);
    if (pg_num_rows($results2) == 1)
       { //Performing SQL Query
          $sql = "UPDATE inventory SET processor_model='$processor_model', speed='$speed', memory='$memory', brand='$brand', ip_add='$ipadd', computer_name='$computer_name', os='$os', end_user='$end_user', type='$type', antivirus='$antivirus' , status='$status' , location='$location' , createdate = current_timestamp WHERE property_number='$property_number'";

           $result_pn1 = pg_query($db,$sql);

            $property_number = "";
            $processor_model = "";
            $speed = "";
            $memory = "";
            $brand = "";
            $ipadd = "";
            $computer_name = "";
            $os = "";
            $end_user = "";
            $type = "";
            $antivirus = "";
            $status = "";
            $location = "";

           array_push($Success, "Record Sucessfully Updated");
         } else {
      array_push($error, "Record not found");

    }
         

 }   




// ... 


// DELETE RECORD
if(isset($_POST['delete'])){
 
    
      $del = $_POST['property_number'];
  
    // Performing SQL query
     
    $query3 = "SELECT * FROM inventory WHERE property_number='$del'";
    $results3 = pg_query($db, $query3);
    if (pg_num_rows($results3) == 1)
       {
          $query2 = "DELETE FROM inventory WHERE property_number = '$del'";
           $result_pn2 = pg_query($db,$query2);

           $property_number = "";
            $processor_model = "";
            $speed = "";
            $memory = "";
            $brand = "";
            $ipadd = "";
            $computer_name = "";
            $os = "";
            $end_user = "";
            $type = "";
            $antivirus = "";
            $status = "";
            $location = "";

           array_push($Success, "Record Sucessfully Deleted");
    } else {
array_push($error, "Record not found");

      
        }
   }
         
  


// ... 

// SEARCH RECORD
if(isset($_POST['search'])){


  
          $searchq = $_POST['property_number'];

// Performing SQL query
  $query1 = pg_query($db, "SELECT * FROM inventory WHERE property_number = '$searchq' LIMIT 1");

   
  //Retrieving information from database
   if(pg_num_rows($query1) == 1)
   {
    while ($row = pg_fetch_array($query1))

    {
            $property_number = $row ['property_number'];
            $processor_model = $row ['processor_model'];
            $speed = $row ['speed'];
            $memory = $row ['memory'];
            $brand = $row ['brand'];
            $ipadd = $row ['ip_add'];
            $computer_name = $row ['computer_name'];
            $os = $row ['os'];
            $end_user = $row ['end_user'];
            echo "<option selected='selected'>" .$row['type']. "</option>";
            $antivirus = $row ['antivirus'];
            $status = $row ['status'];
            $location = $row ['location'];
            

            
            

            }
  

   
   } else {
      array_push($error, "Record not found");

            $property_number = "";
            $processor_model = "";
            $speed = "";
            $memory = "";
            $brand = "";
            $ipadd = "";
            $computer_name = "";
            $os = "";
            $end_user = "";
            $type = "";
            $antivirus = "";
            $status = "";
            $location = "";

            
            }
       

          pg_free_result($query1);          
                    
           pg_close($db);
   }



// ... 
 //CLEAR FIELDS

  if(isset($_POST['clear'])){
  
  header('location:Inventory.php');

}



  //Filter Search


?>